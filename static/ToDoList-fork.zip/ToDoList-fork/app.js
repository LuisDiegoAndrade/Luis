var enterButton = document.getElementById("enter");

// button to delete all list items
var deleteAllBtn = document.getElementById("deleteAllBtn");
deleteAllBtn.addEventListener("click", deleteAllItems);

var input = document.getElementById("userInput");
var ul = document.querySelector("ul");
var item = document.getElementsByTagName("li");



function inputLength() {
	return input.value.length;
}


function createListElement() {

	var li = document.createElement("li");
	// Will contain the li text; I decided to add this because it will make it easier to target the li's text only.
	var listText = document.createElement('span');


	// The event has to be hooked to the span element (list text) in order to avoid targeting the wrong html element
	listText.addEventListener("dblclick", editListItem);

	listText.innerText = input.value;
	// set a class="list-item" to li elements so later on we can fetch all list items for manupulations
	li.setAttribute('class', 'list-item');
	li.appendChild(listText);
	ul.appendChild(li);
	input.value = "";

	//li.innerHTML += createPositionSelector();




	var dBtn = document.createElement("button");
	dBtn.appendChild(document.createTextNode("X"));
	// eventlistener is implemented in html instead of DOM
	dBtn.setAttribute('onclick', 'deleteListItem()');
	li.appendChild(dBtn);
	/*let reorder = document.createElement('button');
	reorder.appendChild(document.createTextNode("Reorder"));
	li.appendChild(reorder);*/


	// call back for dblclick event listener
	function editListItem() {
		let msg = window.prompt('Edit list description', event.target.innerText);
		if(msg != null && msg != '') {
			event.target.innerText = msg;
		}
		//console.log(event.target.children[0]);
	}

	li.addEventListener("click", crossOut);
	function crossOut() {
		li.classList.toggle("done");
	}

	/*reorder.addEventListener('click', reOrderList);
	function reOrderList() {

		let listItems = document.getElementsByClassName('list-item');
		if(listItems.length == 1){
			alert('More than one list item is needed to re-order!');
		} else {
			let position1 = window.prompt('Select a position from 1-' + listItems.length );
				if(isNaN(parseInt(position1)) || parseInt(position1) > listItems.length) {
					alert('Enter a valid position!');
				} else {
					console.log(event.target.parentNode.outerHTML);
					console.log(listItems[parseInt(position1)-1].outerHTML);

					let tmp = listItems[parseInt(position1)-1].outerHTML;
					listItems[parseInt(position1)-1].outerHTML = event.target.parentNode.outerHTML;
					event.target.parentNode.outerHTML = tmp;

				}

		}
	}

*/
}
//took this function out of the createListElement() function to have global scope
function deleteListItem() {
	event.target.parentNode.remove();
}




function addListAfterClick() {

	if (inputLength() > 0) {
		createListElement();
	}
}


function deleteAllItems() {
	//Returns an HTMLcollection, or a collection of html elements with the class attribute 'list-item'
	let listItems = document.getElementsByClassName('list-item');
	//See what it contains here
	console.log(listItems);
	//syntatic sugar for for loop: for(let i = 0; i < listItems.length; ++i)
	for(item of listItems) {
		//console.log(item);
		item.remove();
	}
	// Since you are changing li's css display property to 'delete', it doesnt entirely remove it from the DOM rather just hide it
	let i = 0;
	while(listItems[i] != null){
		console.log('running')
		listItems[i].remove();
		i++;
	}
	/* -----------
	=====================  super hard coded :( */
	console.log(listItems[0]);
	if(listItems[0] != null)
	listItems[0].remove();
	i = 0;
	console.log(listItems);
}


function addListAfterKeypress(event) {
	if (inputLength() > 0 && event.which === 13) {
		createListElement();
	}
}

enterButton.addEventListener("click", addListAfterClick);

input.addEventListener("keypress", addListAfterKeypress);

// Add functionality to print list as a pdf
function print_list() {

	// will hold list text
	let finalText = null;

	// Open new window
	let list_window = window.open();

	// insert a title
	list_window.document.write("<h1 style='font-size:16px'><strong> List: </strong></h1>");

	// Insert text of each list item followed by a <br>
	// element so each item can start on a new line
	let items = document.querySelectorAll('li');

	items.forEach((item) => {
		//console.log(item);
		//remove X (this is the remove button)
		finalText = item.textContent.slice(0, -1);
		list_window.document.write(`<p style='font-size: 14px'><strong>${finalText}</strong></p>`);

	});

	list_window.print();
	list_window.close();

}
